﻿// Copyright 2009-2012 Matvei Stefarov <me@matvei.org>

namespace fCraft.HeartbeatSaver
{
    enum ReturnCode
    {
        UsageError = 1,
        HeartbeatDataReadingError = 2
    }
}