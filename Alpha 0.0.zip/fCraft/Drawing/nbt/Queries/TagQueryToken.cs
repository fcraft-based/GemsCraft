﻿namespace GemsCraft.Drawing.nbt.Queries
{
    public class TagQueryToken
    {
        public TagQuery Query { get; internal set; }
        public string Name { get; internal set; }
    }
}
