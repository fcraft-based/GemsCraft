﻿using System;

namespace GemsCraft.Drawing.nbt.Exceptions
{
    public class NbtQueryException : Exception
    {
        public NbtQueryException(string message) : base(message) { }
    }
}
