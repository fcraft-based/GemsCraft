﻿// Copyright 2009-2012 Matvei Stefarov <me@matvei.org>

namespace GemsCraft.Drawing {
    public enum Axis {
        X, Y, Z
    }
}