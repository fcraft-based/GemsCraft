﻿// Copyright 2009-2012 Matvei Stefarov <me@matvei.org>

namespace GemsCraft.Utils {
    public enum YesNoAuto {
        Auto,
        Yes,
        No
    }
}